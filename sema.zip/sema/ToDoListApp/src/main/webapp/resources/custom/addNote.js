function addNote(){
	var param = {
			title:$("#note_title").val(),
			content:$("#note_detail").val()
	}
	
	var ser_data = JSON.stringify(param);
	
	$.ajax({
		type:"POST",
		contentType:'application/json; charset=UTF-8',
		url:'addNote',
		data: ser_data,
		success:function(data){
			window.open("http://localhost:8080/notalma/index", "_top");
		},error:function(data){
			alert(data);
		}
	});
	
	
	
}