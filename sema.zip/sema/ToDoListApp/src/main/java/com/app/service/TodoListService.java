package com.app.service;


import com.app.model.BaseReturn;
import com.app.model.TodoList;
import com.app.model.User;
import com.app.repository.ToDoListRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TodoListService {

    final static Logger logger = LoggerFactory.getLogger(TodoItemService.class);

    @Autowired
    private ToDoListRepository toDoListRepository;

    public BaseReturn<TodoList> createTodolist(TodoList todoList, int userId) {
        try {
            logger.info("TodoListService, createTodolist");
            BaseReturn<TodoList> baseReturn = new BaseReturn<>();

            TodoList todoList1 = toDoListRepository.findByNameAndId(todoList.getName(),userId);

            if (null == todoList1 && null != todoList.getName()) {
                todoList.setUser(new User(userId));
                toDoListRepository.save(todoList);
                baseReturn.setMessage("Todolist saved succesfully.");
                baseReturn.setResponse(true);
                logger.info("Todolist saved succesfully.");
            } else {
                baseReturn.setMessage("Todolist cannot be saved.");
                baseReturn.setResponse(false);
                baseReturn.setObj(todoList1);
                logger.info("Todolist cannot be saved. " + "Todolist name: " + todoList.getName());
            }
            return baseReturn;
        } catch (Exception ex) {
            logger.error("TodoList cannot be created !" + "Error message: " + ex.getMessage());
            return new BaseReturn<>("TodoList cannot be created.",false);
        }
    }


    public BaseReturn<List<TodoList>> getAllTodoList(int userId) {
        try {
            logger.info("TodoListService, getAllTodoList");
            List<TodoList> todoLists= toDoListRepository.findByUserId(userId);
            return new BaseReturn<>("TodoList returned succesfully.",todoLists);
        } catch (Exception ex) {
            logger.error("TodoList cannot be listed ! " + "Error message: " + ex.getMessage());
            return new BaseReturn<>("TodoList cannot be listed.",false);
        }
    }

    public BaseReturn<TodoList> deleteTodoList(int todoListId) {
        try {
            logger.info("TodoListService, deleteTodoList");
            toDoListRepository.deleteById(todoListId);
            logger.info("TodoList deleted succesfully." + "Deleted Id: " +todoListId);
            return new BaseReturn<>("TodoList deleted succesfully." + "Deleted Id: " +todoListId);
        } catch (Exception ex) {
            logger.error("TodoList cannot be deleted ! " + "Error message: " + ex.getMessage() + "Todolist Id: " + todoListId);
            return new BaseReturn<>("TodoList cannot be deleted.");
        }
    }
}
