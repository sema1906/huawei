package com.app.repository;

import com.app.model.TodoItem;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ToDoItemRepository extends CrudRepository<TodoItem,Integer> {
    @Query(value = "SELECT * FROM todo_item t WHERE t.to_do_list_id = :todoListId",nativeQuery = true)
    List<TodoItem> findByTodoListId(@Param("todoListId") int todoListId);
}
