package com.app.model;


import javax.persistence.*;
import java.util.Date;

@Entity
public class TodoItem {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column
    private String name;

    @Column
    private String description;

    @Column
    private Date deadline;

    @Column
    private String status;

    @ManyToOne
    @JoinColumn(name = "toDoList_id")
    private TodoList todoList;

    public TodoItem() {
    }

    public TodoItem(String name, String description, Date deadline, String status, TodoList todoList) {
        this.name = name;
        this.description = description;
        this.deadline = deadline;
        this.status = status;
        this.todoList = todoList;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public TodoList getTodoList() {
        return todoList;
    }

    public void setTodoList(TodoList todoList) {
        this.todoList = todoList;
    }
}
