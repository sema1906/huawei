package com.app.service;

import com.app.model.BaseReturn;
import com.app.model.TodoItem;
import com.app.model.TodoList;
import com.app.repository.ToDoItemRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class TodoItemService {

    final static Logger logger = LoggerFactory.getLogger(TodoItemService.class);

    @Autowired
    private ToDoItemRepository toDoItemRepository;

    public BaseReturn<TodoItem> createTodoItem(TodoItem todoItem, int todoListId) {
        try {
            logger.info("TodoItemService, createTodoItem");
            todoItem.setTodoList(new TodoList(todoListId));
            toDoItemRepository.save(todoItem);
            logger.info("TodoItem created succesfully.");
            return new BaseReturn<>("TodoItem created succesfully.",true);

        } catch (Exception ex) {
            logger.error("TodoItem cannot be created ! " + "Error message: " + ex.getMessage() + " "
                                                                + "Error StackTrace: " + ex.getStackTrace());
            return new BaseReturn<>("TodoItem cannot be created",false);
        }
    }

    public BaseReturn<List<TodoItem>> getAllTodoItems(int todoListId) {
        try {
            logger.info("TodoItemService, getAllTodoItems");
            List<TodoItem> todoItems= toDoItemRepository.findByTodoListId(todoListId);
            logger.info("TodoItems returned succesfully.");
            return new BaseReturn<>("TodoItems returned succesfully.",todoItems);
        } catch (Exception ex) {
            logger.error("TodoItem cannot be returned ! " + "Error message: " + ex.getMessage() + " "
                                                                 + "Error StackTrace: " + ex.getStackTrace());
            return new BaseReturn<>("TodoItem cannot be returned",false);
        }
    }

    public BaseReturn<TodoItem> deleteTodoItem(int todoItemId) {
        try {
            logger.info("TodoItemService, deleteTodoItem");
            toDoItemRepository.deleteById(todoItemId);
            logger.info("TodoItems deleted succesfully.");
            return new BaseReturn<>("TodoItems deleted succesfully.");
        } catch (Exception ex){
            logger.error("TodoItem cannot be deleted ! " + "Error message: " + ex.getMessage() + " "
                                                                + "Error StackTrace: " + ex.getStackTrace());
            return new BaseReturn<>("TodoItem cannot be deleted",false);
        }
    }
}
