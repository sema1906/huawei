package com.app.web;

import com.app.model.BaseReturn;
import com.app.model.TodoList;
import com.app.service.TodoListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/todoitem")
public class TodoListController {

    @Autowired
    private TodoListService todoListService;
    
 

    @PostMapping(value = "/create/{userId}")
    public BaseReturn<TodoList> createTodoList(@RequestBody TodoList todoList, @PathVariable("userId") int userId) {
        return todoListService.createTodolist(todoList,userId);
    }

    @GetMapping(value = "/alltodolist/{userId}")
    public BaseReturn<List<TodoList>> getAllTodoList(@PathVariable("userId") int userId) {
        return todoListService.getAllTodoList(userId);
    }

    @DeleteMapping(value = "/{todoListId}")
    public BaseReturn<TodoList> deleteTodoList(@PathVariable("todoListId") int todoListId){
        return todoListService.deleteTodoList(todoListId);
    }
}
