package com.app.model;


import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;

@Entity
public class TodoList {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column
    private String name;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @JsonIgnore
    @OneToMany(mappedBy = "todoList", orphanRemoval = true)
    private Set<TodoItem> todoItems;

    public TodoList() { }

    public TodoList(int id) {
        this.id = id;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() { return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public User getUser() { return user;
    }

    public void setUser(User user) { this.user = user;
    }

    public Set<TodoItem> getTodoItems() {
        return todoItems;
    }

    public void setTodoItems(Set<TodoItem> todoItems) {
        this.todoItems = todoItems;
    }
    
    @Override
	public String toString() {
		return "Note [id=" + id + ", name=" + name + ", user_id=" + user + "]";
	}

}
