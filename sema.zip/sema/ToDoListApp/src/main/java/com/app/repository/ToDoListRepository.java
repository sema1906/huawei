package com.app.repository;

import com.app.model.TodoList;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ToDoListRepository extends CrudRepository<TodoList, Integer> {
    @Query(value = "SELECT * FROM todo_list t WHERE t.name = :name and t.user_id =:userId",nativeQuery = true)
    TodoList findByNameAndId(@Param("name") String name,@Param("userId") int userId);

    @Query(value = "SELECT * FROM todo_list t WHERE t.user_id = :userId",nativeQuery = true)
    List<TodoList> findByUserId(@Param("userId") int userId);
}
