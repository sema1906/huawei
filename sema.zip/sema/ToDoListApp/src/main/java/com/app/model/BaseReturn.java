package com.app.model;

public class BaseReturn<T> {

	   private String message;
	    private boolean response;
	    private T obj;

	    public BaseReturn() {
	    }

	    public BaseReturn(String message) {
	        this.message = message;
	    }

	    public BaseReturn(String message, boolean response) {
	        this.message = message;
	        this.response = response;
	    }

	    public BaseReturn(String message, T obj) {
	        this.message = message;
	        this.obj = obj;
	    }

	    public BaseReturn(String message, boolean response, T obj) {
	        this.message = message;
	        this.response = response;
	        this.obj = obj;
	    }

	    public String getMessage() {
	        return message;
	    }

	    public void setMessage(String message) {
	        this.message = message;
	    }

	    public boolean isResponse() {
	        return response;
	    }

	    public void setResponse(boolean response) {
	        this.response = response;
	    }

	    public T getObj() {
	        return obj;
	    }

	    public void setObj(T obj) {
	        this.obj = obj;
	    }
	}
