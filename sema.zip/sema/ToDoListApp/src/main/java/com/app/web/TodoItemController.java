package com.app.web;

import com.app.model.BaseReturn;
import com.app.model.TodoItem;
import com.app.model.TodoList;
import com.app.service.TodoItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "api/todoitem")
public class TodoItemController {


    @Autowired
    private TodoItemService todoItemService;

    @PostMapping(value = "/create/{todoListId}")
    public BaseReturn<TodoItem> createTodoItem(@RequestBody TodoItem todoItem, @PathVariable("todoListId") int todoListId) {
        return todoItemService.createTodoItem(todoItem,todoListId);
    }

    @GetMapping(value = "/{todoListId}")
    public BaseReturn<List<TodoItem>> getAllTodoItems(@PathVariable("todoListId") int todoListId){
        return todoItemService.getAllTodoItems(todoListId);
    }

    @DeleteMapping(value = "/{todoItemId}")
    public BaseReturn<TodoItem> deleteTodoItem(@PathVariable("todoItemId") int todoItemId){
        return todoItemService.deleteTodoItem(todoItemId);
    }
}
